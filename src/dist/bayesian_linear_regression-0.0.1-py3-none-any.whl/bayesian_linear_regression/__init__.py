from . import bayesian_linear_regeression

name = 'bayesian_linear_regeression'
